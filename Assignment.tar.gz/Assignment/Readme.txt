1) Open Python script hello.py in folder FirstProject.
2) Run hello.py
--------------------------------------------------------------------------------------------------
3) Data from txt file is already been loaded on postgres DB. (You can find it on Postgres script).
4) Total no. of files being used: 3. (i.e., hello.py, data.csv,Assignment.html,postgres DB).
--------------------------------------------------------------------------------------------------
5) On submitting new data, data is being added to the fieldof table (mydata) named 'dataname' in DB (named postgres).
6)There is a search box to search each relevant words, letters, or any other matching combination.
--------------------------------------------------------------------------------------------------
7) Technologies being used are (Python flask, SQLalchemy, Vue.js, html, Postgres DB).
