from flask import Flask, url_for, render_template
from flask_sqlalchemy import SQLAlchemy
from flask import request,redirect

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:toor@localhost/postgres'
app.debug = True
db = SQLAlchemy(app)

class mydata(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    dataname = db.Column(db.CHAR(50), unique=True)
    def __init__(self, dataname):
        self.dataname  = dataname
    def __repr__(self):
        return '<mydata %r>' % self.dataname

@app.route('/')
def index():
    myUser = mydata.query.all()
    return render_template('Assignment.html', myUser=myUser)

@app.route('/post_user', methods=['POST'])
def post_user():
    myData = mydata(request.form['dataname'])
    db.session.add(myData)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.debug = True
    app.run()